# SanTrack - Sanitation Inspection Tracking App

## Overview

SanTrack is a mobile-first sanitation inspection tracking application built with Expo (React Native). It allows sanitation officers to log facility inspections, assign risk scores, and visualize risk data through dashboards with charts. The app tracks inspection locations (latitude/longitude), officer assignments, risk levels (HIGH/MEDIUM/LOW), and notes for facilities in what appears to be the Lagos, Nigeria area.

The project uses a dual architecture: an Expo/React Native frontend for the mobile app and an Express.js backend server. Data is currently stored locally on-device using AsyncStorage with seed data, while a PostgreSQL database schema exists on the server side (currently only handling users).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Expo / React Native)

- **Framework**: Expo SDK 54 with React Native 0.81, using expo-router for file-based routing
- **Routing**: Tab-based navigation with three tabs: Dashboard, Inspections, and Add. Detail view at `detail/[id]` for individual inspections
- **State Management**: TanStack React Query for async data fetching and cache invalidation
- **Local Storage**: AsyncStorage for persisting inspection data on-device (`lib/storage.ts`). Seed data is auto-loaded on first use
- **Charts**: Custom SVG-based chart components (PieChart, LineChart, BarChart) built with `react-native-svg` — no external charting library
- **Fonts**: Inter font family (Regular, SemiBold, Bold) via `@expo-google-fonts/inter`
- **UI Components**: Custom component library in `components/` including StatCard, RiskBadge, InspectionCard, RiskChart, and chart views
- **Platform Support**: iOS, Android, and Web (with platform-specific adjustments for keyboard handling, haptics, and tab bar styling)
- **Design System**: Centralized color constants in `constants/colors.ts` with a light theme focused on cyan/teal primary colors and red/amber/green risk indicators

### Backend (Express.js)

- **Server**: Express 5 running on the same Replit instance, handles CORS for Replit domains and localhost
- **Routes**: Defined in `server/routes.ts` — currently minimal with placeholder for `/api` routes
- **Storage Layer**: `server/storage.ts` implements an in-memory storage pattern (`MemStorage`) with an `IStorage` interface for future database migration
- **Database Schema**: Drizzle ORM with PostgreSQL dialect. Currently only a `users` table defined in `shared/schema.ts` with id, username, and password fields
- **Schema Validation**: Zod schemas generated from Drizzle table definitions via `drizzle-zod`

### Data Flow

- The frontend currently operates independently using AsyncStorage — it does NOT fetch inspection data from the server API
- The `lib/query-client.ts` has infrastructure for making API calls to the Express server (using `EXPO_PUBLIC_DOMAIN`), but inspections CRUD goes through `lib/storage.ts` (AsyncStorage)
- The server-side storage and database schema are set up for users only and don't yet handle inspections

### Key Data Model (Client-Side)

```typescript
interface Inspection {
  id: string;           // UUID generated via expo-crypto
  officerId: string;    // Officer identifier
  lat: number;          // Latitude
  lon: number;          // Longitude
  riskScore: number;    // 0-10 scale
  status: "HIGH RISK" | "MEDIUM RISK" | "LOW RISK";  // Derived from riskScore
  date: string;         // Date string (YYYY-MM-DD)
  notes: string;        // Inspection notes
  facilityName: string; // Name of inspected facility
}
```

Risk classification: score >= 7 = HIGH RISK, score >= 4 = MEDIUM RISK, below 4 = LOW RISK.

### Build & Development

- **Dev mode**: Runs Expo dev server and Express server concurrently on Replit
- **Production build**: Static web export via custom `scripts/build.js`, server bundled with esbuild
- **Database migrations**: `drizzle-kit push` for schema changes
- **Patches**: Uses `patch-package` (runs on postinstall)

## External Dependencies

- **PostgreSQL**: Configured via `DATABASE_URL` environment variable, used by Drizzle ORM for server-side data (currently users only)
- **AsyncStorage**: Client-side persistent storage for inspection data (React Native)
- **Expo Services**: Splash screen, haptics, crypto (UUID generation), image picker, location, font loading
- **TanStack React Query**: Client-side data fetching and caching
- **Drizzle ORM + drizzle-zod**: Database ORM and schema validation (PostgreSQL dialect)
- **Express.js v5**: Backend HTTP server
- **http-proxy-middleware**: Used in development to proxy requests between Expo and Express
- **expo-router**: File-based routing with typed routes enabled
- **react-native-svg**: Custom chart rendering
- **react-native-reanimated / gesture-handler / screens**: Navigation and animation primitives
- **expo-haptics**: Tactile feedback on native platforms