import React, { useCallback, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  Platform,
  RefreshControl,
  ActivityIndicator,
} from "react-native";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { getInspections, deleteInspection, type Inspection } from "@/lib/storage";
import { InspectionCard } from "@/components/InspectionCard";

type FilterType = "ALL" | "HIGH RISK" | "MEDIUM RISK" | "LOW RISK";

const FILTERS: { label: string; value: FilterType }[] = [
  { label: "All", value: "ALL" },
  { label: "High", value: "HIGH RISK" },
  { label: "Medium", value: "MEDIUM RISK" },
  { label: "Low", value: "LOW RISK" },
];

export default function InspectionsScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const [activeFilter, setActiveFilter] = useState<FilterType>("ALL");

  const { data: inspections, isLoading } = useQuery({
    queryKey: ["inspections"],
    queryFn: getInspections,
  });

  const deleteMutation = useMutation({
    mutationFn: deleteInspection,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["inspections"] }),
  });

  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["inspections"] });
    setRefreshing(false);
  }, [queryClient]);

  const filtered = (inspections || []).filter((i) =>
    activeFilter === "ALL" ? true : i.status === activeFilter
  );

  const filterColor = (f: FilterType) => {
    if (f === "HIGH RISK") return Colors.high;
    if (f === "MEDIUM RISK") return Colors.medium;
    if (f === "LOW RISK") return Colors.low;
    return Colors.primary;
  };

  const renderItem = useCallback(
    ({ item }: { item: Inspection }) => (
      <View style={styles.cardWrap}>
        <InspectionCard
          inspection={item}
          onPress={() =>
            router.push({
              pathname: "/detail/[id]",
              params: { id: item.id },
            })
          }
        />
      </View>
    ),
    []
  );

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { paddingTop: insets.top + webTopInset }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <Text style={styles.title}>Inspections</Text>
        <Text style={styles.count}>{filtered.length} records</Text>
      </View>

      <View style={styles.filterRow}>
        {FILTERS.map((f) => {
          const isActive = activeFilter === f.value;
          const color = filterColor(f.value);
          return (
            <Pressable
              key={f.value}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.selectionAsync();
                setActiveFilter(f.value);
              }}
              style={[
                styles.filterChip,
                isActive && { backgroundColor: color, borderColor: color },
              ]}
            >
              <Text
                style={[
                  styles.filterLabel,
                  isActive && { color: Colors.white },
                ]}
              >
                {f.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: Platform.OS === "web" ? 34 : 100 },
        ]}
        scrollEnabled={!!filtered.length}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
        }
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="search-outline" size={40} color={Colors.textTertiary} />
            <Text style={styles.emptyText}>No inspections found</Text>
            <Text style={styles.emptySubtext}>
              {activeFilter === "ALL"
                ? "Add your first inspection"
                : `No ${activeFilter.toLowerCase()} inspections`}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.text,
  },
  count: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    marginTop: 2,
  },
  filterRow: {
    flexDirection: "row",
    paddingHorizontal: 20,
    gap: 8,
    marginBottom: 14,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  filterLabel: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
  },
  listContent: {
    paddingHorizontal: 20,
    gap: 10,
  },
  cardWrap: {},
  emptyState: {
    alignItems: "center",
    paddingVertical: 60,
    gap: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
  },
  emptySubtext: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textTertiary,
  },
});
