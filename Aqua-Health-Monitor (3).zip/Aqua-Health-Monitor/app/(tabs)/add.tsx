import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ScrollView,
  Platform,
  Alert,
  KeyboardAvoidingView,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import Colors from "@/constants/colors";
import { addInspection } from "@/lib/storage";

export default function AddInspectionScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const [facilityName, setFacilityName] = useState("");
  const [officerId, setOfficerId] = useState("");
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const [riskScore, setRiskScore] = useState("");
  const [notes, setNotes] = useState("");

  const mutation = useMutation({
    mutationFn: addInspection,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["inspections"] });
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Success", "Inspection added successfully");
      setFacilityName("");
      setOfficerId("");
      setLat("");
      setLon("");
      setRiskScore("");
      setNotes("");
      router.push("/(tabs)/inspections");
    },
    onError: () => {
      Alert.alert("Error", "Failed to save inspection");
    },
  });

  const handleSubmit = () => {
    if (!facilityName.trim() || !officerId.trim() || !riskScore.trim()) {
      Alert.alert("Missing Fields", "Please fill in facility name, officer ID, and risk score");
      return;
    }
    const score = parseFloat(riskScore);
    if (isNaN(score) || score < 0 || score > 10) {
      Alert.alert("Invalid Score", "Risk score must be between 0 and 10");
      return;
    }
    const latNum = parseFloat(lat) || 0;
    const lonNum = parseFloat(lon) || 0;

    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    mutation.mutate({
      facilityName: facilityName.trim(),
      officerId: officerId.trim().toUpperCase(),
      lat: latNum,
      lon: lonNum,
      riskScore: score,
      notes: notes.trim(),
      date: new Date().toISOString().split("T")[0],
    });
  };

  const getRiskPreview = () => {
    const score = parseFloat(riskScore);
    if (isNaN(score)) return null;
    if (score >= 7) return { label: "HIGH RISK", color: Colors.high, bg: Colors.highBg };
    if (score >= 4) return { label: "MEDIUM RISK", color: Colors.medium, bg: Colors.mediumBg };
    return { label: "LOW RISK", color: Colors.low, bg: Colors.lowBg };
  };

  const riskPreview = getRiskPreview();

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={90}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: Platform.OS === "web" ? 34 : 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>New Inspection</Text>
        <Text style={styles.subtitle}>Log a water sanitation inspection</Text>

        <View style={styles.form}>
          <View style={styles.field}>
            <Text style={styles.label}>Facility Name *</Text>
            <View style={styles.inputWrap}>
              <Ionicons name="business-outline" size={18} color={Colors.textTertiary} />
              <TextInput
                style={styles.input}
                value={facilityName}
                onChangeText={setFacilityName}
                placeholder="e.g. Ikeja Water Point"
                placeholderTextColor={Colors.textTertiary}
              />
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Officer ID *</Text>
            <View style={styles.inputWrap}>
              <Ionicons name="person-outline" size={18} color={Colors.textTertiary} />
              <TextInput
                style={styles.input}
                value={officerId}
                onChangeText={setOfficerId}
                placeholder="e.g. OFF001"
                placeholderTextColor={Colors.textTertiary}
                autoCapitalize="characters"
              />
            </View>
          </View>

          <View style={styles.row}>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={styles.label}>Latitude</Text>
              <View style={styles.inputWrap}>
                <TextInput
                  style={styles.input}
                  value={lat}
                  onChangeText={setLat}
                  placeholder="6.5244"
                  placeholderTextColor={Colors.textTertiary}
                  keyboardType="decimal-pad"
                />
              </View>
            </View>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={styles.label}>Longitude</Text>
              <View style={styles.inputWrap}>
                <TextInput
                  style={styles.input}
                  value={lon}
                  onChangeText={setLon}
                  placeholder="3.3792"
                  placeholderTextColor={Colors.textTertiary}
                  keyboardType="decimal-pad"
                />
              </View>
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Risk Score (0-10) *</Text>
            <View style={styles.inputWrap}>
              <Ionicons name="speedometer-outline" size={18} color={Colors.textTertiary} />
              <TextInput
                style={styles.input}
                value={riskScore}
                onChangeText={setRiskScore}
                placeholder="0.0 - 10.0"
                placeholderTextColor={Colors.textTertiary}
                keyboardType="decimal-pad"
              />
              {riskPreview && (
                <View style={[styles.riskPreview, { backgroundColor: riskPreview.bg }]}>
                  <View style={[styles.riskDot, { backgroundColor: riskPreview.color }]} />
                  <Text style={[styles.riskText, { color: riskPreview.color }]}>
                    {riskPreview.label}
                  </Text>
                </View>
              )}
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Notes</Text>
            <View style={[styles.inputWrap, styles.textArea]}>
              <TextInput
                style={[styles.input, { minHeight: 80, textAlignVertical: "top" }]}
                value={notes}
                onChangeText={setNotes}
                placeholder="Describe findings, issues, or observations..."
                placeholderTextColor={Colors.textTertiary}
                multiline
                numberOfLines={4}
              />
            </View>
          </View>
        </View>

        <Pressable
          onPress={handleSubmit}
          disabled={mutation.isPending}
          style={({ pressed }) => [
            styles.submitBtn,
            pressed && { opacity: 0.9, transform: [{ scale: 0.98 }] },
            mutation.isPending && { opacity: 0.6 },
          ]}
        >
          {mutation.isPending ? (
            <ActivityIndicator color={Colors.white} />
          ) : (
            <>
              <Ionicons name="add-circle-outline" size={20} color={Colors.white} />
              <Text style={styles.submitText}>Save Inspection</Text>
            </>
          )}
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.text,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    marginTop: 2,
    marginBottom: 24,
  },
  form: {
    gap: 18,
  },
  field: {
    gap: 6,
  },
  label: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
    letterSpacing: 0.3,
  },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 14,
    gap: 10,
  },
  textArea: {
    alignItems: "flex-start",
    paddingTop: 12,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    color: Colors.text,
    paddingVertical: 14,
  },
  row: {
    flexDirection: "row",
    gap: 12,
  },
  riskPreview: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  riskDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  riskText: {
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.3,
  },
  submitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primary,
    borderRadius: 14,
    paddingVertical: 16,
    gap: 8,
    marginTop: 28,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  submitText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.white,
  },
});
