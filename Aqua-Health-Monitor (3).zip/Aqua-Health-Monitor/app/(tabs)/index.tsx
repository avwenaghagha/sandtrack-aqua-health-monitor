import React, { useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Pressable,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import Colors from "@/constants/colors";
import { getInspections, getStats, type Inspection } from "@/lib/storage";
import { StatCard } from "@/components/StatCard";
import { PieChartView } from "@/components/PieChartView";
import { LineChartView } from "@/components/LineChartView";
import { BarChartView } from "@/components/BarChartView";
import { InspectionCard } from "@/components/InspectionCard";

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: inspections, isLoading, refetch } = useQuery({
    queryKey: ["inspections"],
    queryFn: getInspections,
  });

  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["inspections"] });
    setRefreshing(false);
  }, [queryClient]);

  const stats = getStats(inspections || []);
  const recentInspections = (inspections || []).slice(0, 3);

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { paddingTop: insets.top + webTopInset }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: insets.top + webTopInset + 12,
          paddingBottom: Platform.OS === "web" ? 34 : 100,
        },
      ]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
      }
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>SanTrack</Text>
          <Text style={styles.subtitle}>Water Sanitation Command Centre</Text>
        </View>
        <View style={styles.headerBadge}>
          <Ionicons name="water" size={18} color={Colors.primary} />
        </View>
      </View>

      <View style={styles.statsGrid}>
        <StatCard title="Total" value={stats.total} icon="clipboard-outline" color={Colors.primary} bgColor="#E0F7FA" />
        <StatCard title="High Risk" value={stats.high} icon="warning-outline" color={Colors.high} bgColor={Colors.highBg} />
      </View>
      <View style={styles.statsGrid}>
        <StatCard title="Medium Risk" value={stats.medium} icon="alert-circle-outline" color={Colors.medium} bgColor={Colors.mediumBg} />
        <StatCard title="Low Risk" value={stats.low} icon="checkmark-circle-outline" color={Colors.low} bgColor={Colors.lowBg} />
      </View>

      <PieChartView
        data={[
          { label: "High Risk", value: stats.high, color: Colors.high },
          { label: "Medium Risk", value: stats.medium, color: Colors.medium },
          { label: "Low Risk", value: stats.low, color: Colors.low },
        ]}
      />

      <LineChartView inspections={inspections || []} />

      <BarChartView inspections={inspections || []} />

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Recent Inspections</Text>
        <Pressable onPress={() => router.push("/(tabs)/inspections")} hitSlop={12}>
          <Text style={styles.seeAll}>See all</Text>
        </Pressable>
      </View>

      <View style={styles.inspectionList}>
        {recentInspections.map((item) => (
          <InspectionCard
            key={item.id}
            inspection={item}
            onPress={() =>
              router.push({
                pathname: "/detail/[id]",
                params: { id: item.id },
              })
            }
          />
        ))}
        {recentInspections.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="document-text-outline" size={40} color={Colors.textTertiary} />
            <Text style={styles.emptyText}>No inspections yet</Text>
            <Text style={styles.emptySubtext}>Add your first inspection to get started</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    paddingHorizontal: 20,
    gap: 14,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  greeting: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.text,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    marginTop: 2,
  },
  headerBadge: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: "#E0F7FA",
    alignItems: "center",
    justifyContent: "center",
  },
  statsGrid: {
    flexDirection: "row",
    gap: 12,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 6,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
  },
  seeAll: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.primary,
  },
  inspectionList: {
    gap: 10,
  },
  emptyState: {
    alignItems: "center",
    paddingVertical: 40,
    gap: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
  },
  emptySubtext: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textTertiary,
  },
});
