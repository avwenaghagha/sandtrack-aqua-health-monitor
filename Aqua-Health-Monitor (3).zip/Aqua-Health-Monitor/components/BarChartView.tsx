import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Rect, Text as SvgText, Defs, LinearGradient, Stop } from "react-native-svg";
import Colors from "@/constants/colors";
import type { Inspection } from "@/lib/storage";

interface BarChartViewProps {
  inspections: Inspection[];
}

function getBarColor(score: number) {
  if (score >= 7) return Colors.high;
  if (score >= 4) return Colors.medium;
  return Colors.low;
}

export function BarChartView({ inspections }: BarChartViewProps) {
  const top = [...inspections]
    .sort((a, b) => b.riskScore - a.riskScore)
    .slice(0, 5);

  if (top.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Top Risky Locations</Text>
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No data available</Text>
        </View>
      </View>
    );
  }

  const maxScore = 10;
  const barH = 26;
  const gap = 10;
  const labelW = 100;
  const scoreW = 40;
  const chartW = 140;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Top Risky Locations</Text>
      <View style={styles.bars}>
        {top.map((item, i) => {
          const pct = (item.riskScore / maxScore) * 100;
          const color = getBarColor(item.riskScore);
          return (
            <View key={item.id} style={styles.barRow}>
              <Text style={styles.barLabel} numberOfLines={1}>
                {item.facilityName}
              </Text>
              <View style={styles.barTrack}>
                <View
                  style={[
                    styles.barFill,
                    { width: `${Math.max(pct, 5)}%`, backgroundColor: color },
                  ]}
                />
              </View>
              <Text style={[styles.barScore, { color }]}>
                {item.riskScore.toFixed(1)}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
  },
  title: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
    marginBottom: 14,
  },
  bars: {
    gap: 10,
  },
  barRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  barLabel: {
    width: 100,
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  barTrack: {
    flex: 1,
    height: 10,
    backgroundColor: Colors.surfaceAlt,
    borderRadius: 5,
    overflow: "hidden",
  },
  barFill: {
    height: "100%",
    borderRadius: 5,
  },
  barScore: {
    width: 32,
    textAlign: "right",
    fontSize: 13,
    fontFamily: "Inter_700Bold",
  },
  emptyState: {
    paddingVertical: 30,
    alignItems: "center",
  },
  emptyText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textTertiary,
  },
});
