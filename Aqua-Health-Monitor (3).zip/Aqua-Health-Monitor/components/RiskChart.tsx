import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Colors from "@/constants/colors";

interface RiskChartProps {
  high: number;
  medium: number;
  low: number;
  total: number;
}

function BarSegment({ label, count, total, color, bgColor }: { label: string; count: number; total: number; color: string; bgColor: string }) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <View style={styles.barRow}>
      <View style={styles.barLabel}>
        <View style={[styles.barDot, { backgroundColor: color }]} />
        <Text style={styles.barLabelText}>{label}</Text>
      </View>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${Math.max(pct, 3)}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.barCount, { color }]}>{count}</Text>
    </View>
  );
}

export function RiskChart({ high, medium, low, total }: RiskChartProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Risk Distribution</Text>
      <View style={styles.bars}>
        <BarSegment label="High" count={high} total={total} color={Colors.high} bgColor={Colors.highBg} />
        <BarSegment label="Medium" count={medium} total={total} color={Colors.medium} bgColor={Colors.mediumBg} />
        <BarSegment label="Low" count={low} total={total} color={Colors.low} bgColor={Colors.lowBg} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
  },
  title: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
    marginBottom: 16,
  },
  bars: {
    gap: 12,
  },
  barRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  barLabel: {
    flexDirection: "row",
    alignItems: "center",
    width: 72,
    gap: 6,
  },
  barDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  barLabelText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  barTrack: {
    flex: 1,
    height: 8,
    backgroundColor: Colors.surfaceAlt,
    borderRadius: 4,
    overflow: "hidden",
  },
  barFill: {
    height: "100%",
    borderRadius: 4,
  },
  barCount: {
    width: 24,
    textAlign: "right",
    fontSize: 14,
    fontFamily: "Inter_700Bold",
  },
});
