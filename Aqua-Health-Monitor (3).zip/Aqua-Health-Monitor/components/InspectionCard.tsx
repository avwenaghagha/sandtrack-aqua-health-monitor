import React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Colors from "@/constants/colors";
import { RiskBadge } from "./RiskBadge";
import type { Inspection } from "@/lib/storage";

interface InspectionCardProps {
  inspection: Inspection;
  onPress: () => void;
}

export function InspectionCard({ inspection, onPress }: InspectionCardProps) {
  const riskColor = {
    "HIGH RISK": Colors.high,
    "MEDIUM RISK": Colors.medium,
    "LOW RISK": Colors.low,
  }[inspection.status];

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={[styles.riskBar, { backgroundColor: riskColor }]} />
      <View style={styles.content}>
        <View style={styles.topRow}>
          <Text style={styles.facility} numberOfLines={1}>
            {inspection.facilityName}
          </Text>
          <RiskBadge status={inspection.status} compact />
        </View>
        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <Ionicons name="person-outline" size={13} color={Colors.textSecondary} />
            <Text style={styles.metaText}>{inspection.officerId}</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="calendar-outline" size={13} color={Colors.textSecondary} />
            <Text style={styles.metaText}>{inspection.date}</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="speedometer-outline" size={13} color={Colors.textSecondary} />
            <Text style={styles.metaText}>{inspection.riskScore.toFixed(1)}</Text>
          </View>
        </View>
        <Text style={styles.notes} numberOfLines={1}>{inspection.notes}</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} style={styles.chevron} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    backgroundColor: Colors.surface,
    borderRadius: 14,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1,
  },
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.99 }],
  },
  riskBar: {
    width: 4,
  },
  content: {
    flex: 1,
    padding: 14,
    gap: 8,
  },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  facility: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
    marginRight: 8,
  },
  metaRow: {
    flexDirection: "row",
    gap: 14,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  notes: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textTertiary,
  },
  chevron: {
    alignSelf: "center",
    marginRight: 10,
  },
});
