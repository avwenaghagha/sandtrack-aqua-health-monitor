import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Path, Circle, Line, Text as SvgText } from "react-native-svg";
import Colors from "@/constants/colors";
import type { Inspection } from "@/lib/storage";

interface LineChartViewProps {
  inspections: Inspection[];
}

export function LineChartView({ inspections }: LineChartViewProps) {
  const sorted = [...inspections].sort((a, b) => a.date.localeCompare(b.date));

  const dateMap = new Map<string, { total: number; count: number }>();
  sorted.forEach((ins) => {
    const existing = dateMap.get(ins.date);
    if (existing) {
      existing.total += ins.riskScore;
      existing.count += 1;
    } else {
      dateMap.set(ins.date, { total: ins.riskScore, count: 1 });
    }
  });

  const points = Array.from(dateMap.entries()).map(([date, { total, count }]) => ({
    date: date.slice(5),
    avg: total / count,
  }));

  if (points.length < 2) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Risk Trend Over Time</Text>
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>Need more data points for trend</Text>
        </View>
      </View>
    );
  }

  const width = 300;
  const height = 150;
  const padL = 30;
  const padR = 16;
  const padT = 12;
  const padB = 28;
  const chartW = width - padL - padR;
  const chartH = height - padT - padB;

  const maxVal = Math.max(...points.map((p) => p.avg), 10);
  const minVal = 0;

  const getX = (i: number) => padL + (i / (points.length - 1)) * chartW;
  const getY = (v: number) => padT + chartH - ((v - minVal) / (maxVal - minVal)) * chartH;

  const pathD = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${getX(i)} ${getY(p.avg)}`)
    .join(" ");

  const areaD = `${pathD} L ${getX(points.length - 1)} ${padT + chartH} L ${getX(0)} ${padT + chartH} Z`;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Risk Trend Over Time</Text>
      <Svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        {[0, 2.5, 5, 7.5, 10].map((v) => (
          <React.Fragment key={v}>
            <Line
              x1={padL}
              y1={getY(v)}
              x2={width - padR}
              y2={getY(v)}
              stroke={Colors.borderLight}
              strokeWidth={1}
            />
            <SvgText
              x={padL - 6}
              y={getY(v) + 4}
              fontSize={9}
              fill={Colors.textTertiary}
              textAnchor="end"
              fontFamily="Inter_400Regular"
            >
              {v.toFixed(0)}
            </SvgText>
          </React.Fragment>
        ))}

        <Path d={areaD} fill={Colors.primary} opacity={0.08} />
        <Path d={pathD} stroke={Colors.primary} strokeWidth={2.5} fill="none" strokeLinejoin="round" strokeLinecap="round" />

        {points.map((p, i) => (
          <React.Fragment key={i}>
            <Circle cx={getX(i)} cy={getY(p.avg)} r={4} fill={Colors.surface} stroke={Colors.primary} strokeWidth={2} />
            <SvgText
              x={getX(i)}
              y={height - 6}
              fontSize={9}
              fill={Colors.textTertiary}
              textAnchor="middle"
              fontFamily="Inter_400Regular"
            >
              {p.date}
            </SvgText>
          </React.Fragment>
        ))}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
  },
  title: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
    marginBottom: 14,
  },
  emptyState: {
    paddingVertical: 30,
    alignItems: "center",
  },
  emptyText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textTertiary,
  },
});
