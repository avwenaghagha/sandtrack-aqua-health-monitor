import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Colors from "@/constants/colors";

type RiskStatus = "HIGH RISK" | "MEDIUM RISK" | "LOW RISK";

interface RiskBadgeProps {
  status: RiskStatus;
  compact?: boolean;
}

export function RiskBadge({ status, compact }: RiskBadgeProps) {
  const config = {
    "HIGH RISK": { bg: Colors.highBg, color: Colors.high, label: compact ? "HIGH" : "HIGH RISK" },
    "MEDIUM RISK": { bg: Colors.mediumBg, color: Colors.medium, label: compact ? "MED" : "MEDIUM RISK" },
    "LOW RISK": { bg: Colors.lowBg, color: Colors.low, label: compact ? "LOW" : "LOW RISK" },
  }[status];

  return (
    <View style={[styles.badge, { backgroundColor: config.bg }]}>
      <View style={[styles.dot, { backgroundColor: config.color }]} />
      <Text style={[styles.label, { color: config.color }]}>{config.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    gap: 5,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  label: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.5,
  },
});
