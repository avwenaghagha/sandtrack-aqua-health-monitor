import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Path, Circle } from "react-native-svg";
import Colors from "@/constants/colors";

interface PieSlice {
  label: string;
  value: number;
  color: string;
}

interface PieChartViewProps {
  data: PieSlice[];
  size?: number;
}

function polarToCartesian(cx: number, cy: number, r: number, angle: number) {
  const rad = ((angle - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function createArcPath(cx: number, cy: number, r: number, startAngle: number, endAngle: number) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return `M ${cx} ${cy} L ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 0 ${end.x} ${end.y} Z`;
}

export function PieChartView({ data, size = 160 }: PieChartViewProps) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 4;

  let currentAngle = 0;
  const slices = data.map((d) => {
    const angle = total > 0 ? (d.value / total) * 360 : 0;
    const startAngle = currentAngle;
    currentAngle += angle;
    return { ...d, startAngle, endAngle: currentAngle };
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Risk Distribution</Text>
      <View style={styles.chartRow}>
        <Svg width={size} height={size}>
          {total === 0 ? (
            <Circle cx={cx} cy={cy} r={r} fill={Colors.surfaceAlt} />
          ) : (
            slices.map((slice, i) =>
              slice.endAngle - slice.startAngle > 0.1 ? (
                <Path
                  key={i}
                  d={createArcPath(cx, cy, r, slice.startAngle, slice.endAngle - 0.5)}
                  fill={slice.color}
                />
              ) : null
            )
          )}
          <Circle cx={cx} cy={cy} r={r * 0.55} fill={Colors.surface} />
          <Circle cx={cx} cy={cy} r={r * 0.55} fill={Colors.surface} />
        </Svg>
        <View style={styles.legend}>
          {data.map((d, i) => (
            <View key={i} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: d.color }]} />
              <View style={styles.legendText}>
                <Text style={styles.legendLabel}>{d.label}</Text>
                <Text style={[styles.legendValue, { color: d.color }]}>{d.value}</Text>
              </View>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
  },
  title: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: Colors.text,
    marginBottom: 14,
  },
  chartRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 20,
  },
  legend: {
    flex: 1,
    gap: 12,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  legendLabel: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  legendValue: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
});
