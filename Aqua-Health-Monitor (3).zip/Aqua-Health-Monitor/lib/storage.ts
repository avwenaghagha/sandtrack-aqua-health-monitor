import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Crypto from "expo-crypto";

export interface Inspection {
  id: string;
  officerId: string;
  lat: number;
  lon: number;
  riskScore: number;
  status: "HIGH RISK" | "MEDIUM RISK" | "LOW RISK";
  date: string;
  notes: string;
  facilityName: string;
}

const STORAGE_KEY = "santrack_inspections";

function getRiskStatus(score: number): Inspection["status"] {
  if (score >= 7) return "HIGH RISK";
  if (score >= 4) return "MEDIUM RISK";
  return "LOW RISK";
}

const SEED_DATA: Inspection[] = [
  { id: "seed-1", officerId: "OFF001", lat: 6.5244, lon: 3.3792, riskScore: 8.75, status: "HIGH RISK", date: "2026-02-20", notes: "Contaminated water source detected near residential area", facilityName: "Ikeja Water Point" },
  { id: "seed-2", officerId: "OFF002", lat: 6.6018, lon: 3.3515, riskScore: 1.2, status: "LOW RISK", date: "2026-02-20", notes: "Facility meets all sanitation standards", facilityName: "Agege Treatment Plant" },
  { id: "seed-3", officerId: "OFF003", lat: 6.4500, lon: 3.4000, riskScore: 6.5, status: "MEDIUM RISK", date: "2026-02-21", notes: "Minor pipe leakage observed, repair scheduled", facilityName: "Victoria Island Pump" },
  { id: "seed-4", officerId: "OFF004", lat: 6.5000, lon: 3.3500, riskScore: 9.25, status: "HIGH RISK", date: "2026-02-21", notes: "Severe sewage overflow near school compound", facilityName: "Surulere Main Line" },
  { id: "seed-5", officerId: "OFF005", lat: 6.5500, lon: 3.3800, riskScore: 2.0, status: "LOW RISK", date: "2026-02-22", notes: "Routine check passed. No issues found", facilityName: "Yaba Borehole Station" },
  { id: "seed-6", officerId: "OFF001", lat: 6.4312, lon: 3.4218, riskScore: 7.8, status: "HIGH RISK", date: "2026-02-22", notes: "High coliform bacteria count in water sample", facilityName: "Lekki Phase 1 Well" },
  { id: "seed-7", officerId: "OFF003", lat: 6.5822, lon: 3.3411, riskScore: 3.5, status: "LOW RISK", date: "2026-02-22", notes: "Chlorine levels within acceptable range", facilityName: "Ogba Reservoir" },
];

export async function getInspections(): Promise<Inspection[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  if (!raw) {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_DATA));
    return SEED_DATA;
  }
  return JSON.parse(raw);
}

export async function addInspection(data: Omit<Inspection, "id" | "status">): Promise<Inspection> {
  const inspections = await getInspections();
  const newInspection: Inspection = {
    ...data,
    id: Crypto.randomUUID(),
    status: getRiskStatus(data.riskScore),
  };
  inspections.unshift(newInspection);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(inspections));
  return newInspection;
}

export async function deleteInspection(id: string): Promise<void> {
  const inspections = await getInspections();
  const filtered = inspections.filter((i) => i.id !== id);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
}

export function getStats(inspections: Inspection[]) {
  const high = inspections.filter((i) => i.status === "HIGH RISK").length;
  const medium = inspections.filter((i) => i.status === "MEDIUM RISK").length;
  const low = inspections.filter((i) => i.status === "LOW RISK").length;
  const avgScore = inspections.length > 0 ? inspections.reduce((a, b) => a + b.riskScore, 0) / inspections.length : 0;
  return { high, medium, low, total: inspections.length, avgScore };
}
